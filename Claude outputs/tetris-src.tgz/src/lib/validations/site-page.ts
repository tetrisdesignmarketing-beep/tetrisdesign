import { z } from "zod";
import { VN_PROVINCES } from "@/lib/vn-provinces";
import { mediaPathSchema } from "@/lib/validations/shared";
import { isValidPartnerHref, normalizePartnerHref } from "@/lib/partner-href";
import {
  isValidSocialHref,
  normalizeSocialHref,
  type SocialKey,
} from "@/lib/social-links";

export const SITE_PAGE_SLUGS = [
  "home",
  "about",
  "projects",
  "services",
  "contact",
] as const;

export const sitePageSlugSchema = z.enum(SITE_PAGE_SLUGS);

export type SitePageSlug = z.infer<typeof sitePageSlugSchema>;

export function isSitePageSlug(value: string): value is SitePageSlug {
  return (SITE_PAGE_SLUGS as readonly string[]).includes(value);
}

export const heroScreenTypeSchema = z.enum(["MOBILE", "DESKTOP"]);

export type HeroScreenType = z.infer<typeof heroScreenTypeSchema>;

export const heroSlideSchema = z.object({
  image: mediaPathSchema,
  title: z.string().min(1, "Tiêu đề slide không được để trống").max(200),
  location: z.string().min(1, "Địa điểm không được để trống").max(200),
  /** Để trống → nút "XEM DỰ ÁN" fallback sang /projects (xem resolveHeroSlideHref). */
  href: z.string().max(500).optional().default(""),
  /** Legacy JSON thiếu field → MOBILE. */
  screenType: heroScreenTypeSchema.default("MOBILE"),
});

export const homePageSchema = z.object({
  slides: z.array(heroSlideSchema).min(1, "Cần ít nhất một slide"),
});

/** Form admin — mỗi section = 1 cặp ảnh Mobile + Desktop. */
export const homePageFormSlideSchema = z.object({
  title: z.string().min(1, "Tiêu đề slide không được để trống").max(200),
  location: z.string().min(1, "Địa điểm không được để trống").max(200),
  /** Để trống → nút "XEM DỰ ÁN" fallback sang /projects. */
  href: z.string().max(500),
  mobileImage: mediaPathSchema,
  desktopImage: mediaPathSchema,
});

export const homePageFormSchema = z.object({
  slides: z.array(homePageFormSlideSchema).min(1, "Cần ít nhất một slide"),
});

const awardItemSchema = z.object({
  year: z.number().int().min(1900).max(3000),
  title: z.string().min(1).max(300),
});

const awardGroupSchema = z.object({
  title: z.string().min(1).max(200),
  items: z.array(awardItemSchema).min(1),
});

/**
 * Link logo đối tác — lưu DB / đọc public. `optional` để JSON cũ (chưa có
 * field) vẫn parse được (không rơi về nội dung mặc định). Chuẩn hoá khi lưu:
 * tự thêm https://, bỏ scheme không phải http(s).
 */
const partnerHrefStoredSchema = z
  .string()
  .max(2048)
  .optional()
  .transform((value) => normalizePartnerHref(value));

/** Form admin — luôn là string (input = output cho RHF + zodResolver). */
const partnerHrefFormSchema = z
  .string()
  .max(2048, "Link tối đa 2048 ký tự")
  .refine(
    isValidPartnerHref,
    "Link không hợp lệ (vd. amway.com hoặc https://amway.com)",
  );

export const aboutPageSchema = z.object({
  heroImage: mediaPathSchema,
  brandBreakImage: mediaPathSchema,
  introduction: z.object({
    title: z.string().min(1).max(200),
    paragraphs: z.array(z.string().min(1)).min(1),
  }),
  awards: z.object({
    title: z.string().min(1).max(200),
    groups: z.array(awardGroupSchema).min(1),
  }),
  journey: z.object({
    title: z.string().min(1).max(200),
    paragraphs: z.array(z.string().min(1)).min(1),
  }),
  partners: z.object({
    title: z.string().min(1).max(200),
    items: z
      .array(
        z.object({
          name: z.string().min(1).max(200),
          logo: mediaPathSchema,
          href: partnerHrefStoredSchema,
        }),
      )
      .min(1),
  }),
});

/** Form admin About — giống `aboutPageSchema`, chỉ khác `href` đối tác. */
export const aboutPageFormSchema = aboutPageSchema.extend({
  partners: z.object({
    title: z.string().min(1).max(200),
    items: z
      .array(
        z.object({
          name: z.string().min(1).max(200),
          logo: mediaPathSchema,
          href: partnerHrefFormSchema,
        }),
      )
      .min(1),
  }),
});

export const siteServiceSchema = z.object({
  title: z.string().min(1).max(200),
  /** Nhãn phụ (vd. tiếng Anh "BRAND IDENTITY") — hiện trên mô tả; không bắt buộc. */
  label: z.string().trim().max(120).optional(),
  description: z.string().min(1),
  image: mediaPathSchema,
  imageAlt: z.string().min(1).max(200),
});

/** Layout trang /services admin chọn: service = mặc định, service1 = xấp ảnh, service2 = cột co giãn. */
export const SERVICES_LAYOUTS = ["service", "service1", "service2"] as const;
export type ServicesLayout = (typeof SERVICES_LAYOUTS)[number];
export const DEFAULT_SERVICES_LAYOUT: ServicesLayout = "service";
export const servicesLayoutSchema = z.enum(SERVICES_LAYOUTS);

export const servicesPageSchema = z.object({
  /* Không bắt buộc (không dùng .default để input/output RHF cùng type);
     dữ liệu cũ chưa có layout → đọc là DEFAULT_SERVICES_LAYOUT. */
  layout: servicesLayoutSchema.optional(),
  items: z.array(siteServiceSchema).min(1, "Cần ít nhất một dịch vụ"),
});

/** `z.enum` giữ input/output cùng type — tránh lệch Resolver với RHF + zodResolver. */
const vnProvinceField = z.enum(VN_PROVINCES, {
  error: "Chọn tỉnh / thành phố",
});

/** Form admin — luôn là string (input = output cho RHF + zodResolver). */
function socialHrefFormField(key: SocialKey) {
  return z
    .string()
    .max(2048)
    .refine((value) => isValidSocialHref(key, value), {
      message:
        key === "zalo"
          ? "Nhập số điện thoại hoặc link Zalo hợp lệ"
          : "Link không hợp lệ (vd. facebook.com/tentrang)",
    });
}

/** Lưu DB — chuẩn hoá lại phía server; thiếu/sai → "" (ẩn icon). */
function socialHrefStoredField(key: SocialKey) {
  return z
    .string()
    .max(2048)
    .optional()
    .transform((value) => normalizeSocialHref(key, value));
}

export const contactSocialFormSchema = z.object({
  facebook: socialHrefFormField("facebook"),
  instagram: socialHrefFormField("instagram"),
  tiktok: socialHrefFormField("tiktok"),
  behance: socialHrefFormField("behance"),
  zalo: socialHrefFormField("zalo"),
});

const contactSocialStoredSchema = z.object({
  facebook: socialHrefStoredField("facebook"),
  instagram: socialHrefStoredField("instagram"),
  tiktok: socialHrefStoredField("tiktok"),
  behance: socialHrefStoredField("behance"),
  zalo: socialHrefStoredField("zalo"),
});

/** Form admin — chưa ghép `address` (ghép lúc submit). */
export const contactPageFormSchema = z.object({
  email: z.email("Email không hợp lệ"),
  phone: z.string().min(1, "Số điện thoại không được để trống").max(50),
  /** Mã số thuế — để trống thì ẩn trên trang Liên hệ. 10 số, hoặc 10 số + "-" + 3 số (chi nhánh). */
  taxCode: z
    .string()
    .trim()
    .regex(/^(\d{10}(-\d{3})?)?$/, "Mã số thuế gồm 10 số (hoặc 10 số-3 số)"),
  addressLine: z
    .string()
    .min(1, "Địa chỉ chi tiết không được để trống")
    .max(400, "Địa chỉ chi tiết tối đa 400 ký tự"),
  province: vnProvinceField,
  /** Link icon mạng xã hội ở footer — ô trống = ẩn icon. */
  social: contactSocialFormSchema,
});

/**
 * Lưu DB + public — có `address` đã ghép (line + tỉnh + Việt Nam).
 * `social` optional: dữ liệu lưu trước khi có tính năng này không có trường
 * này → site dùng link mặc định (xem resolveSocialLinks).
 */
export const contactPageSchema = contactPageFormSchema.extend({
  address: z.string().min(1, "Địa chỉ không được để trống").max(500),
  /* Dữ liệu cũ chưa có → dùng mã số thuế mặc định (xem resolveContactTaxCode). */
  taxCode: z.string().trim().max(50).optional(),
  social: contactSocialStoredSchema.optional(),
});

export { contactSocialStoredSchema };

/** Layout /projects — list dự án nằm ở Post, không lưu trong JSON này. */
export const projectsPageSchema = z.object({
  note: z.string().optional(),
});

export const sitePageSchemas = {
  home: homePageSchema,
  about: aboutPageSchema,
  projects: projectsPageSchema,
  services: servicesPageSchema,
  contact: contactPageSchema,
} as const;

export function parseSitePageContent(slug: SitePageSlug, content: unknown) {
  return sitePageSchemas[slug].safeParse(content);
}

export type HomePageContent = z.infer<typeof homePageSchema>;
/** Form admin Home — slides có thể rỗng trước khi lưu. */
export type HomePageFormValues = {
  slides: Array<{
    title: string;
    location: string;
    href: string;
    mobileImage: string;
    desktopImage: string;
  }>;
};

/** Flat CMS slides → form sections (ghép MOBILE[i] + DESKTOP[i]). */
export function homeSlidesToFormValues(
  slides: HomePageContent["slides"],
): HomePageFormValues {
  const mobile = slides.filter((slide) => slide.screenType === "MOBILE");
  const desktop = slides.filter((slide) => slide.screenType === "DESKTOP");

  if (desktop.length === 0) {
    return {
      slides: mobile.map((slide) => ({
        title: slide.title,
        location: slide.location,
        href: slide.href,
        mobileImage: slide.image,
        desktopImage: slide.image,
      })),
    };
  }

  const count = Math.max(mobile.length, desktop.length);
  const formSlides: HomePageFormValues["slides"] = [];
  for (let index = 0; index < count; index += 1) {
    const mobileSlide = mobile[index];
    const desktopSlide = desktop[index];
    const meta = mobileSlide ?? desktopSlide;
    if (!meta) continue;
    formSlides.push({
      title: meta.title,
      location: meta.location,
      href: meta.href,
      mobileImage: mobileSlide?.image ?? desktopSlide?.image ?? "",
      desktopImage: desktopSlide?.image ?? mobileSlide?.image ?? "",
    });
  }
  return { slides: formSlides };
}

/** Form sections → flat CMS slides (MOBILE rồi DESKTOP theo thứ tự section). */
export function homeFormValuesToSlides(
  form: HomePageFormValues,
): HomePageContent["slides"] {
  return form.slides.flatMap((slide) => [
    {
      image: slide.mobileImage,
      title: slide.title,
      location: slide.location,
      href: slide.href,
      screenType: "MOBILE" as const,
    },
    {
      image: slide.desktopImage,
      title: slide.title,
      location: slide.location,
      href: slide.href,
      screenType: "DESKTOP" as const,
    },
  ]);
}

export type AboutPageContent = z.infer<typeof aboutPageSchema>;
export type ServicesPageContent = z.infer<typeof servicesPageSchema>;
/** Form admin Services — items có thể rỗng trước khi lưu. */
export type ServicesPageFormValues = {
  layout?: ServicesLayout;
  items: Array<{
    title: string;
    label?: string;
    description: string;
    image: string;
    imageAlt: string;
  }>;
};
export type ContactPageFormValues = z.infer<typeof contactPageFormSchema>;
export type ContactPageContent = z.infer<typeof contactPageSchema>;
export type ProjectsPageContent = z.infer<typeof projectsPageSchema>;
